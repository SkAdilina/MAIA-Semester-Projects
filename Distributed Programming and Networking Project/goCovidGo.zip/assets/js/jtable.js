$(document).ready(function () {
    $('#StudentTableContainer').jtable({
        title: 'The Student List',
        actions: {
            listAction: '/StudentList',
            deleteAction: '/DeleteStudent',
            updateAction: '/UpdateStudent',
            createAction: '/CreateStudent'
        },
        fields: {
            name: {
                title: 'Name',
                width: '23%'
            },
            email: {
                title: 'Email address',
            },
            sex: {
                title: 'Gender',
                width: '13%',
                options: { 'M': 'Male', 'F': 'Female' }
            },
            birthDate: {
                title: 'Birth date',
                width: '15%',
                type: 'date',
                displayFormat: 'yy-mm-dd'
            },
            nationality: {
                title: 'About this person',
                type: 'textarea',
                list: false
            },
            residence: {
                title: 'Email address',
            },
        }
    });

    //Load student list from server
    $('#StudentTableContainer').jtable('load');
});
