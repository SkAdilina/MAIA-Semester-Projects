const mongoose = require('mongoose');

// Schema
const Schema = mongoose.Schema;
const patientSchema = mongoose.Schema({
    email:{
        type: String,
        required: true
    },
    name:{
        type: String,
        required: true
    },
    password:{
        type: String,
        required: true
    },
    birthdate:{
        type: Date,
        default: Date.now
    },
    nationality: {
        type: String,
        required: true
    },
    sex: {
        type: String,
        required: true
    },
    residence: {
        type: String,
        required: true
    }
})

// Returning Model
const Patient = mongoose.model('Patient' , patientSchema, 'Patient');
module.exports =  Patient;

//const BlogPost = mongoose.model('BlogPost', BlogPostSchema);

