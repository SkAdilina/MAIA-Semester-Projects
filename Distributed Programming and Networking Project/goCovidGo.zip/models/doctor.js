const mongoose = require('mongoose');

// Schema
const Schema = mongoose.Schema;
const doctorSchema = mongoose.Schema({
    email:{
        type: String,
        required: true
    },
    name:{
        type: String,
        required: true
    },
    password:{
        type: String,
        required: true
    },
    licenseID: {
        type: String,
        required: true
    }
})

// Returning Model
const Doctor = mongoose.model('Doctor' , doctorSchema, 'Doctor');
module.exports =  Doctor;


