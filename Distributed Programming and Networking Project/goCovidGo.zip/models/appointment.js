const mongoose = require('mongoose');

// Schema
const Schema = mongoose.Schema;
const appointmentSchema = mongoose.Schema({
    locationID: { type: Schema.Types.ObjectId, ref: 'Location' },
    patientID: { type: Schema.Types.ObjectId, ref: 'Patient' },
    typeOfAppointment:{
        type: String,
        required: true
    },
    active: {
        type: Boolean,
        required: true
    }
})

// Returning Model
const Appointment = mongoose.model('Appointment' , appointmentSchema, 'Appointment');
module.exports =  Appointment;


