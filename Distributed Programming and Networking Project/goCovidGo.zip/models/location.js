const mongoose = require('mongoose');

// Schema
const Schema = mongoose.Schema;
const locationSchema = mongoose.Schema({
    centerName:{
        type: String,
        required: true
    },
    address:{
        type: String,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    country: {
        type: String,
        required: true
    },
    postalCode: {
        type: String,
        required: true
    },
    appointmentDate: {
        type: Date,
        required: true
    },
    appointmentTime: {
        type: String,
        required: true
    }
})

// Returning Model
const Location = mongoose.model('Location' , locationSchema, 'Location');
module.exports =  Location;


