const express = require('express');
const exphbs  = require('express-handlebars');
const bodyParser = require('body-parser');
const flash = require('connect-flash');
const session = require('express-session');
const methodOverride = require('method-override')
const mongoose = require('mongoose');
const moment = require('moment');
const multer = require('multer');
const fs = require('fs');

const app = express();
const port = process.env.Port || 3000;

const uri = "mongodb+srv://dbAdmin:admin@cluster0.ug8tk.mongodb.net/goCovidGo?retryWrites=true&w=majority";

mongoose.connect(uri,{
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Mongoose Listener
mongoose.connection.on('connected', () => {
    console.log("Mongoose Atlas connected");
});


// Data parsing
//app.use(express.json());
//app.use(express.urlencoded({ extended: false}));

//BODY PARSER MIDDLEWARE
app.use(bodyParser.urlencoded({ extended: true}));
app.use(bodyParser.json());

app.use(session({secret:'Keep it secret'
    ,name:'uniqueSessionID'
    ,saveUninitialized:false
}))


//FOLDER FOR STATIC RESOURCES
app.use('/css' , express.static(__dirname + '/assets/css'));
app.use('/js' , express.static(__dirname + '/assets/js'));
app.use('/img' , express.static(__dirname + '/assets/img'));
//app.use('/' , express.static(__dirname + '/assets/'));


//MONGOOSE CONNECTION Patient
//MONGOOSE CONNECTION
mongoose.Promise = global.Promise;

//mongoose.connect('mongodb://localhost/patient')
//    .then(() => console.log(' Server mongo connected patient'))
//    .catch(err => console.log(err));

//SCHEMA AND MODEL
// const Patient = mongoose.model('Patient', patientSchema);


/*
//MONGOOSE CONNECTION doctor
//mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/note' , {
    useMongoClient: true,
})
    .then(() => console.log(' Server mongo connected note'))
    .catch(err => console.log(err));

//SCHEMA AND MODEL
require('./models/note');
const Note = mongoose.model('Note');
*/


//MIDDLEWARE FOR HANDLEBARS
app.engine('handlebars', exphbs({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');


//OVERRIDE MIDDLEWARE
app.use(methodOverride('_method'));


//MIDDLEWARE FOR FLASH MESSAGGES
app.use(flash());

//GLOBAL VARIABLES FOR  FLASH MESSAGGES
app.use((req , res, next)=>{
    res.locals.msg_successo = req.flash('msg_successo');
    res.locals.msg_errore = req.flash('msg_errore');
    res.locals.errore = req.flash('errore');
    next();
});


//ROUTE FOR INDEX PAGE
app.get('/' , (req , res)=>{
    const titolo = "Freedom notes";
    res.render('index' , {titolo: titolo});
})

//ROUTE FOR FAQ PAGINA
app.get('/faq' , (req , res)=>{
    res.render('faq');
})

//ROUTE FOR PROFILE
app.get('/profile' , (req , res)=>{
    res.render('profile');
})

//ROUTE FOR ECOMMERCE PAGINA
app.get('/buy_products' , (req , res)=>{
    res.render('buy_products');
})

//ROUTE FOR SIGN UP PAGINA
app.get('/signup' , (req , res)=>{
    res.render('signup');
})

app.get('/logindoc' , (req , res)=>{
    res.render('logindoc');
})

app.get('/contact' , (req , res)=>{
    res.render('contact');
})

/*ROUTE FOR NOTE LIST PAGE
app.get('/lista_note' , (req , res) =>{

    if(req.session.loggedIn){
        Note.find({})
            .sort({date: 'desc'})
            .then(note => {
                res.render('lista_note' , {
                    note: note
                });
            });
    } else {
        res.redirect("/login");
    }
});*/

// ROUTE TO PROFILE PAGE
app.get('/profile' , (req , res)=>{
    res.render('profile');
})

//ROUTE FOR LOGIN PAGE
app.get('/login' , (req , res)=>{
    res.render('login');
})
app.get('/logindoc' , (req , res)=>{
    res.render('login');
})

app.get('/logout',(req,res)=> {
    req.session.destroy((err)=>{});
    //req.flash('msg_successo','Your have been successfully logged out.');
    res.redirect('/')
})


app.post('/signupdoc', (req, res) => {

    console.log("Enters sign up function");

    const Doctor = require('./models/doctor');
    if (req.body.secret_key!='DPNN'){
        req.flash('msg_errore','Your secret key is incorrect. Are you a doctor?');
        res.redirect('/');
    }
    else{
        let newIncoming = new Doctor({
            email : req.body.email,
            name : req.body.name,
            password : req.body.password,
            licenseID : req.body.licenseID
        });
        newIncoming.save();
        req.flash('msg_successo', 'Successfully Signed up as Doctor');
        res.redirect('/logindoc');
    }

})


// SIGN UP
app.post('/signup', (req, res) => {

    console.log("Enters sign up function");

    const Patient = require('./models/patient');

    let newIncoming = new Patient({
        email : req.body.email,
        name : req.body.name,
        password : req.body.password,
        birthdate : req.body.birthdate,
        nationality : req.body.nationality,
        sex : req.body.sex,
        residence : req.body.residence
    });
    newIncoming.save();
    req.flash('msg_successo', 'Successfully Signed up as Patient');
    res.redirect('/login');
})

// LOGIN

app.post('/authenticatedoc', bodyParser.urlencoded() ,(req,res,next)=> {
    // Actual implementation would check values in a database
    const Doctor = require('./models/doctor');

    let real_res = res;
    let res_email;
    let res_pass;
    let error;
    console.log("Doctor authenticate");
    //console.log(req.body.username);
    //console.log(req.body.password);

    Doctor.findOne({email: req.body.username}, (err, res) => {
        if(err){
            return console.log("Error: " + err);
        }
        error=res;
        console.log(res);
        if(res==null){
            req.flash('msg_errore','Your email is incorrect. Please try again.');
            real_res.redirect('/logindoc');

            //window.alert("login unsuccesful email");
            return console.log("Error: Email does not exits" + err);
        }
        else{
            //console.log("This is the result of findOne");
            //console.log(res.email);

            //console.log(res.password);
            res_email=res.email;
            res_pass=res.password;
            //console.log("pass inside else")
        }
    })

    async function aaa(req) {
        var doc = await Doctor.findOne({email:req.body.username});
        console.log(doc);

        if (error == null) {
            console.log("Wrong email !!!")

            real_res.redirect('/logindoc');

        } else {
            //console.log("The values received after searching");
            //console.log(res_email);
            //console.log(res_pass);
            if (req.body.username == res_email && req.body.password == res_pass) {
                //res.locals.username = req.body.username;
                req.session.loggedIn = true;
                req.session.username = req.body.username;
                req.session.type = 'doctor';
                console.log(req.session);
                req.flash('msg_successo', 'Successfully logged in as Doctor');
                real_res.redirect('/');
                console.log("Login Successful");
            } else {
                console.log("Login Unsuccessful");
                req.flash('msg_errore','Your password is incorrect. Please try again.');
                real_res.redirect('/logindoc');

            }
        }
    }

    aaa(req);
});

app.post('/authenticate', bodyParser.urlencoded() ,(req,res,next)=> {
    // Actual implementation would check values in a database
    const Patient = require('./models/patient');
    let real_res = res;
    let res_email;
    let res_pass;
    let error;
    Patient.findOne({email: req.body.username}, (err, res) => {
        if (err) {
            return console.log("Error: " + err);
        }
        error = res;
        //console.log(res);
        if (res == null) {
            console.log("wrong email");
            req.flash('msg_errore','Email does not exist.');
            real_res.redirect('/login');
            //window.alert("login unsuccesful email");
            //return console.log("Error: Email does not exits" + err);
        } else {
            //console.log("This is the result of findOne");
            //console.log(res.email);
            //console.log(res.password);
            res_email = res.email;
            res_pass = res.password;
            //console.log("pass inside else")
        }
    })
    //console.log("pasa por aca solo");
    async function loginExist(req) {
        var doc = await Patient.findOne({email:req.body.username});
        console.log(doc);
        if (doc == null) {
            console.log("Wrong email !!!");
            req.flash('msg_errore','Email does not exist.');
            real_res.redirect('/login');
        } else {
            console.log("The id received after searching");
            console.log(doc._id);
            if (req.body.username == res_email && req.body.password == res_pass) {
                //res.locals.username = req.body.username;
                req.session.loggedIn = true;
                req.session.username = doc._id;
                req.session.type = 'patient';
                //console.log(req.session);
                req.flash('msg_successo', 'Successfully logged in as Patient');
                real_res.redirect('/');
                console.log("Login Successful");
            } else {
                console.log("Login Unsuccessful");
                req.flash('msg_errore','Your password is incorrect. Please try again.');
                real_res.redirect('/login');
                //alert("login unsuccesful password");
                //res.sendStatus(401);
            }
        }
    }
    loginExist(req);
});

//ROUTE TO BOOK AN APPOINTMENT
app.get('/bookingAppointment', (req , res)=>{
    res.render('bookingAppointment');
})

//ROUTE FOR LIST OF APPOINTMENTS
// app.get('/listBookings', (req , res)=>{
//     res.render('listBookings');
// })

//ROUTE TO PROFILE PAGE OF PATIENT
app.get('/profile', (req , res)=>{
    res.render('profile');
})

//FORM MANAGEMENT: ADDING A NEW BOOKING/APPOINTMENT
app.post('/add_booking', bodyParser.urlencoded() , (req, res) => {

    if(req.session.type=='patient') {

        const Location = require('./models/location');
        const Appointment = require('./models/appointment');

        let real_res = res;
        let real_req = req;
        let error;

        Location.findOne({centerName: req.body.centerName, appointmentDate: req.body.appointmentDate, appointmentTime: req.body.appointmentTime},(err, res) => {
            if (err) {
                console.log("Location.findOne err");
                //req.flash('msg_errore', 'Something went wrong. Please try again.');
                //real_res.redirect('/bookingAppointment');
            }
            if(res == null) {
                req.flash('msg_errore', 'The slot has been removed. Please try again.');
                real_res.redirect('/bookingAppointment');
                console.log("Not found");
            }
            else {
                Appointment.findOne({locationID : res._id}, (err_app, res_app) => {
                    //console.log("this slot was booked before, now what to do?");
                    console.log(res);
                    if (err_app) {
                        req.flash('msg_errore', 'Something went wrong. Please try again.');
                        real_res.redirect('/bookingAppointment');
                    }
                    if(res_app == null)
                    {
                        console.log("Booking can be made");
                        //console.log(real_req.body.typeOfAppointment);
                        let newIncoming = new Appointment({
                            locationID: res._id,
                            patientID: req.session.username,
                            active: true,
                            typeOfAppointment: real_req.body.typeOfAppointment
                        });
                        newIncoming.save();
                        //console.log(newIncoming);
                        req.flash('msg_successo', 'Booking Confirmed.');
                        real_res.redirect('/bookingAppointment');
                    }
                    else
                    {
                        console.log("Booking cannot be made");
                        req.flash('msg_errore', 'The slot is already booked. Please try again.');
                        real_res.redirect('/bookingAppointment');
                    }
                })

                console.log("Found");
            }
            return res;
        })

        //console.log(req.body.centerName);
        async function locationExist(req) {
            var doc = await Location.findOne(req);
            //console.log("printing in aaa");
            //console.log(doc);
            if (err) {
                console.log("LocationExist err");
                req.flash('msg_errore', 'Something went wrong. Please try again.');
                real_res.redirect('/bookingAppointment');
            }
        }
        locationExist(req);
    } else {
        req.flash('msg_errore','You need to log in as patient to book an appointment.');
        res.redirect("login");
    }

});


//FORM MANAGEMENT: VIEWING BOOKING HISTORY
//new version
//for patients
app.get('/listBookings', function(req, res, next){
    const Appointment = require('./models/appointment');
    const Patient = require('./models/patient');
    const Location = require('./models/location');
    console.log('listBooking')
    if(req.session.type=='patient'){
        Appointment.find({ patientID: req.session.username }).populate({ path: 'patientID', select:[ 'name','email' ]})
            .populate({ path: 'locationID', select:[ 'centerName','appointmentDate','appointmentTime' ]}).lean()
            .then(function(appoint){
                //console.log(appoint)
                res.render('listBookings', {appointment_each: appoint});
            });
    }else{
        req.flash('msg_errore','You need to log in as patient to view the page.');
        res.redirect('/login');
    }
});

//for doctors
app.get('/list_apointments_doc', function(req, res, next){
    const Appointment = require('./models/appointment');
    const Patient = require('./models/patient');
    const Location = require('./models/location');
    if(req.session.type=='doctor'){
        Appointment.find().populate({ path: 'patientID', select:[ 'name','email' ]})
            .populate({ path: 'locationID', select:[ 'centerName','appointmentDate','appointmentTime' ]}).lean()
            .then(function(appoint){
                //console.log(appoint)
                //console.log(appoint.patientID)

                res.render('list_apointments_doc', {appointment_each: appoint});
            });
    }else{
        req.flash('msg_errore','You need to log in as doctor to view the page.');
        res.redirect('/logindoc');
    }
});


/*app.post('/update_patient_booking', (req, res) => {

    const Patient = require('./models/patient');
    let PatientId = req.session.username;
    //console.log(req);
    //console.log(res);
})*/


//FORM MANAGEMENT: VIEWING PROFILE
app.get('/viewProfile', function(req, res, next){

    const Patient = require('./models/patient');
    if(req.session.type=='patient'){
        Patient.findOne({_id: req.session.username}).lean()
            .then(function(appoint){
                //console.log(appoint)
                //console.log(appoint.birthdate)
                appoint.birthdate = moment(appoint.birthdate).format('DD/MM/YYYY');
                //console.log(appoint.birthdate)

                res.render('profile', {patient_profile_info: appoint});
            });
    }else{
        req.flash('msg_errore','You need to log in as patient to view your account.');
        res.redirect("login");
    }
});


app.post('/update_patient_profile', (req, res) => {

    const Patient = require('./models/patient');
    if(req.session.type=='patient'){
    let PatientId = req.session.username;
    console.log(PatientId);

    let newIncoming = {
        _Id : PatientId,
        email : req.body.email,
        name : req.body.name,
        birthdate : req.body.birthdate,
        nationality : req.body.nationality,
        sex : req.body.sex,
        residence : req.body.residence
    }


    Patient.findOne({
        _id: PatientId
    })
        .then(patient =>{
            console.log(patient.email);
            patient.email = newIncoming.email,
            patient.name = newIncoming.name,
            patient.birthdate = newIncoming.birthdate,
            patient.nationality = newIncoming.nationality,
            patient.sex = newIncoming.sex,
            patient.residence = newIncoming.residence
            patient.save()
                .then(nota =>{
                    //res.send({Result: "OK"});
                    req.flash('msg_successo','Your account information was updated succesfully.');
                    res.redirect("/viewProfile");
                })
                .catch(err =>
                    console.log(err)
                );
        })
        .catch(err =>
            console.log(err)
        );
    }else{
        req.flash('msg_errore','You need to log in as patient to edit your profile.');
        res.redirect("login");
    }
})


//MANAGEMENT: REMOVE DOCUMENT
app.post('/delete_booking/:id' , (req , res) =>{
    if(req.session.type=='patient'){
        console.log(req.params.id);
        const Appointment = require('./models/appointment');
        Appointment.deleteOne({
            _id: req.params.id
        })
            .then(nota =>{
                req.flash('msg_successo' ,  'Appointment deleted successfully.');
                res.redirect('/listBookings');
            });
    }else{
        req.flash('msg_errore','Something went wrong. Please try again.');
        res.redirect("/");
    }

});

const upload = multer({
    dest: 'uploads/' // this saves your file into a directory called "uploads"
});

app.post('/upload_file/:id', upload.single('file-to-upload'), (req, res) => {
    let newName = 'report-' + req.params.id + '.pdf';
    //console.log(__dirname + "/" + req.file.destination + "/" + req.file.originalname);
    if(req.session.type=='doctor') {
        fs.renameSync(__dirname + "/" + req.file.path, __dirname + "/" + req.file.destination + "/" + newName, () => {
            console.log("\nFile Renamed with: " + req.file.newName + "!\n");
        });
        req.flash('msg_successo', 'Successfully uploaded the document.');
        res.redirect('/');
    }
    else{
        req.flash('msg_errore','Something went wrong. Please try again.');
        res.redirect("/login");
    }

});

app.post('/upload_file_patient/:id', upload.single('file-to-upload'), (req, res) => {
    let newName = 'patient-' + req.params.id + '.pdf';
    //console.log(__dirname + "/" + req.file.destination + "/" + req.file.originalname);
    if(req.session.type=='patient') {
        fs.renameSync(__dirname + "/" + req.file.path, __dirname + "/" + req.file.destination + "/" + newName, () => {
            console.log("\nFile Renamed with: " + req.file.newName + "!\n");
        });
        req.flash('msg_successo', 'Successfully uploaded the document.');
        res.redirect('/');
    }
    else{
        req.flash('msg_errore','Something went wrong. Please try again.');
        res.redirect("/login");
    }

});

app.get('/download/:id', function(req, res){
    const file = '../goCovidGo_6/uploads/'+'report-' + req.params.id +'.pdf';
    fs.access(file, fs.F_OK, (err) => {
        if (err) {
            console.error(err)
            req.flash('msg_errore','Report is not available yet ');
            res.redirect('/listBookings')
        }
        else{
            console.log(file)
            //console.log(res.download(file))
            res.download(file); // Set disposition and send it.
            // req.flash('msg_successo', 'Report downloaded successfully');
        }}
    )

});



app.post('/look_patient', function(req, res){
    console.log(req.body.myInput)

    const Appointment = require('./models/appointment');
    const Patient = require('./models/patient');
    const Location = require('./models/location');
    if(req.session.type=='doctor'){

        Appointment.find().populate({ path: 'locationID', select:[ 'centerName','appointmentDate','appointmentTime' ]})
            .populate({ path: 'patientID',select:[ 'name','email' ],match: {name:req.body.myInput }}).lean()
            .then(function(appoint){
                console.log(appoint)
                //console.log(appoint.patientID)

                res.render('list_apointments_doc', {appointment_each: appoint});
            });
    }else{
        req.flash('msg_errore','You need to log in as doctor to view the page.');
        res.redirect('/logindoc');
    }

});

app.listen(port, ()=>{
    console.log(`Server listening on port: ${port}`);
})
